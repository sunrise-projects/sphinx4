The binary mbrola.exe in this directory(mbr302a) is
Mbrola 3.02 for native dos uuencoded.
compiled by Donato Taddei

Very little changes are made: only the restriction of
namefiles in the 8.3 standard dos format. 